from collections import defaultdict
from datetime import date, datetime

from flask import Flask, jsonify, render_template, request
from flask_cors import CORS

from ai_service import generate_advice
from config import Config
from models import CATEGORIES, Expense, Income, db


def create_app(config_object=Config):
    app = Flask(__name__)
    app.config.from_object(config_object)
    CORS(app)
    db.init_app(app)

    with app.app_context():
        db.create_all()

    # ---------- helpers ----------
    def month_of(value):
        return value or date.today().strftime("%Y-%m")

    def build_summary(month):
        start = datetime.strptime(month, "%Y-%m").date()
        end = date(start.year + (start.month == 12), start.month % 12 + 1, 1)
        income = sum(i.amount for i in Income.query.filter_by(month=month))
        expenses = Expense.query.filter(Expense.date >= start, Expense.date < end).all()
        by_cat = defaultdict(float)
        for e in expenses:
            by_cat[e.category] += e.amount
        total = sum(by_cat.values())
        return {
            "month": month,
            "income": round(income, 2),
            "total_expenses": round(total, 2),
            "savings": round(income - total, 2),
            "savings_rate": round((income - total) / income * 100, 1) if income else 0,
            "by_category": {k: round(v, 2) for k, v in by_cat.items()},
        }

    def positive_amount(data):
        try:
            amount = float(data.get("amount"))
        except (TypeError, ValueError):
            return None
        return amount if amount > 0 else None

    # ---------- pages ----------
    @app.route("/")
    def index():
        return render_template("index.html", categories=CATEGORIES)

    @app.route("/health")
    def health():
        return jsonify(status="ok")

    # ---------- income ----------
    @app.route("/api/income", methods=["GET", "POST"])
    def income():
        if request.method == "POST":
            data = request.get_json(silent=True) or {}
            amount = positive_amount(data)
            if amount is None:
                return jsonify(error="Amount must be a positive number"), 400
            item = Income(month=month_of(data.get("month")),
                          source=data.get("source", "Salary"), amount=amount)
            db.session.add(item)
            db.session.commit()
            return jsonify(item.to_dict()), 201
        month = month_of(request.args.get("month"))
        return jsonify([i.to_dict() for i in Income.query.filter_by(month=month)])

    @app.route("/api/income/<int:item_id>", methods=["DELETE"])
    def delete_income(item_id):
        item = db.get_or_404(Income, item_id)
        db.session.delete(item)
        db.session.commit()
        return "", 204

    # ---------- expenses ----------
    @app.route("/api/expenses", methods=["GET", "POST"])
    def expenses():
        if request.method == "POST":
            data = request.get_json(silent=True) or {}
            amount = positive_amount(data)
            if amount is None:
                return jsonify(error="Amount must be a positive number"), 400
            category = data.get("category", "Other")
            if category not in CATEGORIES:
                return jsonify(error=f"Category must be one of {CATEGORIES}"), 400
            try:
                when = datetime.strptime(data.get("date") or date.today().isoformat(),
                                         "%Y-%m-%d").date()
            except ValueError:
                return jsonify(error="Date must be YYYY-MM-DD"), 400
            item = Expense(category=category, description=data.get("description", ""),
                           amount=amount, date=when)
            db.session.add(item)
            db.session.commit()
            return jsonify(item.to_dict()), 201
        month = month_of(request.args.get("month"))
        rows = [e for e in Expense.query.order_by(Expense.date.desc())
                if e.date.strftime("%Y-%m") == month]
        return jsonify([e.to_dict() for e in rows])

    @app.route("/api/expenses/<int:item_id>", methods=["DELETE"])
    def delete_expense(item_id):
        item = db.get_or_404(Expense, item_id)
        db.session.delete(item)
        db.session.commit()
        return "", 204

    # ---------- summary / AI / report ----------
    @app.route("/api/summary")
    def summary():
        return jsonify(build_summary(month_of(request.args.get("month"))))

    @app.route("/api/budget-plan", methods=["POST"])
    def budget_plan():
        data = request.get_json(silent=True) or {}
        month = month_of(data.get("month"))
        summary_data = build_summary(month)
        if summary_data["income"] <= 0:
            return jsonify(error="Add your monthly income first"), 400
        return jsonify(generate_advice(summary_data, data.get("goal", "")))

    @app.route("/api/report")
    def report():
        month = month_of(request.args.get("month"))
        summary_data = build_summary(month)
        advice = generate_advice(summary_data) if summary_data["income"] > 0 else None
        return jsonify(summary=summary_data, advice=advice)

    return app


if __name__ == "__main__":
    create_app().run(debug=True)
