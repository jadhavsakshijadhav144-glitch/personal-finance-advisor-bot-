import pytest

from app import create_app


class TestConfig:
    TESTING = True
    SQLALCHEMY_DATABASE_URI = "sqlite:///:memory:"
    GEMINI_API_KEY = ""
    GEMINI_MODEL = "test"


@pytest.fixture
def client():
    return create_app(TestConfig).test_client()


def test_health(client):
    assert client.get("/health").json["status"] == "ok"


def test_income_expense_summary(client):
    client.post("/api/income", json={"amount": 50000, "month": "2026-09"})
    client.post("/api/expenses", json={"amount": 12000, "category": "Rent", "date": "2026-09-05"})
    s = client.get("/api/summary?month=2026-09").json
    assert s["income"] == 50000 and s["savings"] == 38000


def test_invalid_amount(client):
    assert client.post("/api/expenses", json={"amount": -5}).status_code == 400


def test_budget_plan_fallback(client):
    client.post("/api/income", json={"amount": 1000, "month": "2026-09"})
    r = client.post("/api/budget-plan", json={"month": "2026-09"}).json
    assert r["source"] == "rule-based"
