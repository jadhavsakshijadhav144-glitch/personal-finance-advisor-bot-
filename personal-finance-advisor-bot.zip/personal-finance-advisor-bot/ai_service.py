"""Gemini AI integration with a rule-based fallback when no API key is set."""
import json
import re

from flask import current_app


def _model():
    key = current_app.config.get("GEMINI_API_KEY")
    if not key:
        return None
    import google.generativeai as genai

    genai.configure(api_key=key)
    return genai.GenerativeModel(current_app.config["GEMINI_MODEL"])


def _extract_json(text):
    match = re.search(r"\{.*\}", text, re.DOTALL)
    return json.loads(match.group(0)) if match else None


def _fallback_plan(summary):
    """50/30/20-style plan used when Gemini is unavailable."""
    income = summary["income"]
    plan = {
        "needs": round(income * 0.5, 2),
        "wants": round(income * 0.3, 2),
        "savings": round(income * 0.2, 2),
    }
    tips = []
    for cat, amt in sorted(summary["by_category"].items(), key=lambda x: -x[1])[:3]:
        share = (amt / income * 100) if income else 0
        tips.append(f"{cat} is {share:.0f}% of your income. Look for ways to trim it.")
    if not tips:
        tips.append("Log some expenses to receive personalised suggestions.")
    return {
        "source": "rule-based",
        "budget_plan": plan,
        "saving_suggestions": tips,
        "insight": "Following the 50/30/20 rule: 50% needs, 30% wants, 20% savings.",
    }


def generate_advice(summary, goal=""):
    """Return budget plan, saving suggestions and insight for a monthly summary."""
    model = _model()
    if model is None:
        return _fallback_plan(summary)

    prompt = f"""You are a personal finance advisor. Based on this monthly data, respond ONLY
with valid JSON (no markdown) using this schema:
{{"budget_plan": {{"<category>": <recommended amount number>}},
  "saving_suggestions": ["<actionable tip>", "..."],
  "insight": "<2-3 sentence summary of financial health>"}}

Data: {json.dumps(summary)}
User goal: {goal or "Not specified"}
"""
    try:
        result = _extract_json(model.generate_content(prompt).text)
        if result:
            result["source"] = "gemini"
            return result
    except Exception as exc:  # network/quota/parse errors -> fallback
        current_app.logger.warning("Gemini failed: %s", exc)
    return _fallback_plan(summary)
