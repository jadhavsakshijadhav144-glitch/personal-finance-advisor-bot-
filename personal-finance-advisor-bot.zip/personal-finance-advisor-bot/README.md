# Personal Finance Advisor Bot

An AI-powered personal finance assistant. Record monthly income, log daily expenses by category,
and get a personalised budget plan, saving suggestions and a monthly summary report powered by **Google Gemini**.

## Tech stack
- **Backend:** Python, Flask, Flask-SQLAlchemy, SQLite
- **AI:** Google Gemini (with rule-based 50/30/20 fallback if no API key)
- **Frontend:** HTML, CSS, JavaScript

## Features
- Income and expense tracking (rent, food, transport, entertainment, etc.)
- Monthly summary: income, spending, savings and savings rate
- Spending-by-category breakdown
- AI budget plan and saving suggestions, with an optional savings goal
- Monthly report endpoint

## Project structure
```
app.py            Flask app factory and REST API
ai_service.py     Gemini integration + fallback
models.py         SQLAlchemy models (Income, Expense)
config.py         Environment configuration
templates/        HTML
static/           CSS and JS
tests/            pytest tests
```

## Setup
```bash
git clone https://github.com/<your-username>/personal-finance-advisor-bot.git
cd personal-finance-advisor-bot
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env            # then add your GEMINI_API_KEY
python app.py
```
Open http://127.0.0.1:5000. Get a free Gemini key at https://aistudio.google.com/app/apikey.

## API
| Method | Endpoint | Description |
|---|---|---|
| GET/POST | `/api/income` | List / add income |
| GET/POST | `/api/expenses` | List / add expenses |
| DELETE | `/api/income/<id>`, `/api/expenses/<id>` | Remove entry |
| GET | `/api/summary?month=YYYY-MM` | Monthly totals |
| POST | `/api/budget-plan` | AI budget plan (`{month, goal}`) |
| GET | `/api/report?month=YYYY-MM` | Summary + advice |

## Tests
```bash
pytest
```

## Deployment (Render / Railway / Heroku)
- Build: `pip install -r requirements.txt`
- Start: `gunicorn "app:create_app()"` (see `Procfile`)
- Set env vars: `GEMINI_API_KEY`, `SECRET_KEY`

## Future enhancements
Predictive spending analytics, investment suggestions, goal-based savings tracking, user accounts.
